import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import calendar
import os

data = pd.read_csv('BreadBasket_DMS.csv')
datee = data.set_index(['Date'])
sixteen=datee.loc['30-10-2016':'31-12-2016']


popular=sixteen['Item'].value_counts()
print(popular.head())
data.dropna()
data = data[data['Item'] != 'NONE']
data['Date'] = pd.to_datetime(data['Date'])
data['Time'] = pd.to_datetime(data['Time'])
data['Year'] = data['Date'].dt.year
data['Month'] = data['Date'].dt.month
data['Day'] = data['Date'].dt.day
data['Weekday'] = data['Date'].dt.weekday
data['Hour'] = data['Time'].dt.hour
data['Year'] = data['Date'].dt.year

def map_indexes_and_values(df, col):
    df_col = df[col].value_counts()
    x = df_col.index.tolist()
    y = df_col.values.tolist()
    return x, y

weekmap = {0:'Mon', 1:'Tue', 2:'Wed', 3:'Thu', 4:'Fri', 5:'Sat', 6:'Sun'}

first_year_data = data[data['Year'] == 2016]
x, y = map_indexes_and_values(first_year_data, 'Item')
plt.bar(x[:5], y[:5], color='r', label='2016')
plt.xlabel('Most popular Items')
plt.ylabel('Number of Transactions')
plt.legend()
plt.show()